import javax.swing.*;

public class Score {
    private int score;
    private JLabel scoreLabel;

    public Score() {
        score = 0;
        scoreLabel = new JLabel("Score: 0");
    }

    public JLabel getScoreLabel() {
        return scoreLabel;
    }

    public void increaseScore() {
        score++;
        scoreLabel.setText("Score: " + score);
    }

    public void decreaseScore() {
        score--;
        scoreLabel.setText("Score: " + score);
    }
}
