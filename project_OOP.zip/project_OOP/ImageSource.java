public interface ImageSource {
        final static String imgSource = "LatihanGUI/src/Assets/";
}
