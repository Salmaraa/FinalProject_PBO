import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;


public class GameGUI extends JPanel implements ActionListener {
    private JPanel backgroundPanel;
    private JLabel backgroundLabel;
    private JLabel characterLabel;
    private Bush[] bush;
    private JLabel[] bushLabels;
    private Dog dog;
    private Pig pig;
    private JLabel timeLabel;
    private Timer gameTimer;
    private int timeRemaining;
    private int characterX, characterY;
    private boolean isClicked;
    private boolean[] bushLocked;
    private Timer animalTimer;
    private boolean isDogVisible;
    private boolean isPigVisible;

    public GameGUI() {
        characterX = 200;
        characterY = 350;
        isClicked = false;
        isDogVisible = false;
        isPigVisible = false;

        setLayout(new FlowLayout());

        backgroundPanel = new JPanel();
        backgroundPanel.setLayout(null);
        backgroundPanel.setPreferredSize(new Dimension(1280, 832));

        ImageIcon bgImage = new ImageIcon("Assets/bg.png");
        backgroundLabel = new JLabel(bgImage);
        backgroundLabel.setBounds(0, 0, 1280, 832);
        backgroundPanel.add(backgroundLabel);

        add(backgroundLabel);

        ImageIcon characterImage1 = new ImageIcon("Assets/kapak1.png");
        ImageIcon characterImage2 = new ImageIcon("Assets/kapak2.png");
        characterLabel = new JLabel(characterImage1);
        characterLabel.setBounds(characterX, characterY, 100, 100);
        backgroundLabel.add(characterLabel);

        characterLabel.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (isClicked) {
                    characterLabel.setIcon(characterImage1);
                    isClicked = false;
                } else {
                    characterLabel.setIcon(characterImage2);
                    isClicked = true;

                    Timer timer = new Timer(100, new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                            characterLabel.setIcon(characterImage1);
                            isClicked = false;
                        }
                    });
                    timer.setRepeats(false);
                    timer.start();
                }
            }
        });

        backgroundLabel.addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseMoved(MouseEvent e) {
                int mouseX = e.getX();
                int mouseY = e.getY();
                double sensitivity = 1; // Increase or decrease the sensitivity factor as desired

                characterX = mouseX - characterLabel.getWidth() / 2;
                characterY = mouseY - characterLabel.getHeight() / 2;
                characterX *= sensitivity;
                characterY *= sensitivity;
                characterLabel.setLocation(characterX, characterY);
            }
        });



        bushLabels = new JLabel[7];
        int[] bushXCoordinates = {27, 370, 690, 1040, 540, 400, 670};
        int[] bushYCoordinates = {420, 500, 540, 540, 60, 250, 210};

        ImageIcon bushImage = new ImageIcon("Assets/bush.png");
        for (int i = 0; i < bushLabels.length; i++) {
            bushLabels[i] = new JLabel(bushImage);
            bushLabels[i].setBounds(bushXCoordinates[i], bushYCoordinates[i], bushImage.getIconWidth(), bushImage.getIconHeight());
            backgroundLabel.add(bushLabels[i]);
        }


        dog = new Dog(bushLabels);
        backgroundLabel.add(dog.getAnimalLabel());


        pig = new Pig(bushLabels);
        backgroundLabel.add(pig.getAnimalLabel());

        timeLabel = new JLabel("Time: 30");
        timeLabel.setBounds(20, 20, 100, 20);
        backgroundPanel.add(timeLabel);

        add(backgroundPanel, BorderLayout.CENTER);

        bushLocked = new boolean[bushLabels.length];
        for (int i = 0; i < bushLocked.length; i++) {
            bushLocked[i] = false;
        }
        timeLabel = new JLabel("Player 1: Score: 0 | Lives: 3 | Time: 30s");
        timeLabel.setForeground(Color.WHITE);
        timeLabel.setFont(new Font("Arial", Font.BOLD, 20));
        timeLabel.setBounds(10, 10, 400, 30);
        backgroundLabel.add(timeLabel);


        setFocusable(true);
        requestFocusInWindow();
        setVisible(true);

        startGame();

    }

//    public void initialize() {
//        setVisible(true);
//        startGame();
//        dog.getAnimalLabel().setVisible(true);
//        pig.getAnimalLabel().setVisible(true);
//        dog.moveAnimalToRandomBush();
//        pig.moveAnimalToRandomBush();
//
//    }

    public void startGame() {
        timeRemaining = 30;
        gameTimer = new Timer(1000, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                timeRemaining--;
                timeLabel.setText("Time: " + timeRemaining);

                if (timeRemaining == 0) {
                    endGame();
                }
            }
        });
        gameTimer.start();
    }



    public void endGame() {
        gameTimer.stop();
        JOptionPane.showMessageDialog(this, "Game Over!");
    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }

    public void initialize() {
        setVisible(true);
        startGame();
        dog.getAnimalLabel().setVisible(true);
        pig.getAnimalLabel().setVisible(true);

        // Panggil metode moveAnimalToRandomBush() pada karakter dog dan pig secara acak
        for (int i = 0; i < bushLabels.length; i++) {
            dog.moveAnimalToRandomBush();
            pig.moveAnimalToRandomBush();
        }
    }

}
